# CPool2
Android Application

CPool is an simple Android application which helps you meet people interested to accompany you for travel.Ofcourse, you can also split the cab bill......!
Used Java ,XML for coding , and  Firebase as Database.
